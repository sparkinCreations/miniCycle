/**
 * Header / Chrome Layout Manager
 * =============================================================================
 * Measures the fixed "chrome" that the centred fixed panels must avoid, and
 * publishes the measurements as CSS custom properties on `:root`:
 *
 *   --header-total-height   the fixed header (`.fixed-header-container`, which
 *                           wraps the header row AND the mode-selector row)
 *   --nav-dots-clearance    the bottom band the Routine|Stats nav dots occupy,
 *                           i.e. the distance from the nav-dots' top edge to the
 *                           viewport bottom (#nav-dots)
 *
 * Layout rules consume them so the centred panels always clear the chrome at any
 * window size / orientation / safe-area, instead of hardcoded guesses:
 *   - #app-container padding-top reserves --header-total-height
 *   - #task-view and #stats-panel both centre in the BAND between the header and
 *     the nav dots, and cap their height to fit, so the routine title clears the
 *     mode-selector row AND the bottom (help window / dots) never collide:
 *       top: calc(50% + (var(--header-total-height) - var(--nav-dots-clearance)) / 2)
 *
 * If these variables are ever EMPTY (e.g. the measure never ran), the layout
 * falls back to hardcoded guesses (--header-height-fallback) that are too small
 * for a real iOS header — so initHeaderLayout retries until they're published.
 *
 * Why measure instead of pure CSS: these heights are variable — the header
 * depends on `env(safe-area-inset-top)`, the breakpoint padding, the `.ios-pwa`
 * class, the accessibility font-size, and branding wrap; the nav-dots band shifts
 * with viewport height and `env(safe-area-inset-bottom)`. There is no CSS
 * primitive to read one element's rendered geometry into another element's
 * `calc()`, so tiny ResizeObservers do it.
 *
 * Zero app dependencies (DOM + ResizeObserver only) — imported directly by
 * uiBoot, the same way `capacitorBridge` is. Mirrors the established
 * `--first-run-welcome-height` measurement pattern in `onboardingManager`.
 */

import { DOM_SELECTORS, DOM_IDS } from '../core/constants.js';

/** CSS variables layout rules read. Kept here as the single source. */
export const HEADER_HEIGHT_VAR = '--header-total-height';
export const NAV_DOTS_CLEARANCE_VAR = '--nav-dots-clearance';

let _headerObserver = null;
let _navObserver = null;
let _resizeHandler = null;
let _headerEl = null;
let _navEl = null;
let _retryRaf = null;
let _loadHandler = null;

/**
 * Measure the fixed header and publish its height to `:root`.
 * `getBoundingClientRect().height` includes padding, and the safe-area inset
 * lives in the header row's `padding-top`, so this is the full
 * header + mode-selector box height.
 *
 * @returns {number} measured height in px (0 if the header is missing or not yet laid out)
 */
export function measureHeaderHeight() {
    // Query fresh every call. A cached reference can go stale if the header
    // subtree is re-rendered during boot — the stale node then measures 0 and
    // the variable is never published, which is the "--header-total-height is
    // empty on device → layout falls back to the 110px guess → title creeps
    // under the mode selector" bug.
    const el = document.querySelector(DOM_SELECTORS.FIXED_HEADER_CONTAINER);
    if (!el) return 0;
    const height = Math.round(el.getBoundingClientRect().height);
    if (height > 0) {
        document.documentElement.style.setProperty(HEADER_HEIGHT_VAR, `${height}px`);
    }
    return height;
}

/**
 * Measure the bottom band occupied by the Routine|Stats nav dots and publish it
 * as `--nav-dots-clearance` — the distance from the dots' top edge to the
 * viewport bottom. The stats panel reserves this so its bottom never reaches the
 * dots. Uses the dots' (larger) touch-target box, which is conservative.
 *
 * @returns {number} clearance in px (0 if the nav dots are missing or not laid out)
 */
export function measureNavDotsClearance() {
    const el = document.getElementById(DOM_IDS.NAV_DOTS); // fresh — see measureHeaderHeight
    if (!el) return 0;
    const height = el.offsetHeight;
    if (height <= 0) return 0;
    // Use the dots' CSS intent (bottom offset + height), NOT their live
    // getBoundingClientRect().top. The dots are position:absolute inside the
    // content-height #app-container, so on a short viewport with a long routine
    // their rect sits below the fold and a viewport-relative measure would read
    // 0 — yet in stats view (task list hidden) they sit `bottom` px up from the
    // viewport bottom. bottom + height is that stable clearance.
    const bottomPx = parseFloat(getComputedStyle(el).bottom) || 0;
    const clearance = Math.max(0, Math.round(bottomPx + height));
    document.documentElement.style.setProperty(NAV_DOTS_CLEARANCE_VAR, `${clearance}px`);
    return clearance;
}

/** Measure every tracked element in one pass. */
function _measureAll() {
    measureHeaderHeight();
    measureNavDotsClearance();
}

/**
 * Start keeping the layout variables in sync with the live chrome.
 * Idempotent — safe to call more than once (a boot retry re-runs UI setup).
 *
 * @returns {boolean} true if the header was found and observation started
 */
export function initHeaderLayout() {
    _headerEl = document.querySelector(DOM_SELECTORS.FIXED_HEADER_CONTAINER);
    _navEl = document.getElementById(DOM_IDS.NAV_DOTS);

    if (!_headerEl) {
        console.warn(`⚠️ headerLayoutManager: ${DOM_SELECTORS.FIXED_HEADER_CONTAINER} not found yet — the retry below will publish once it appears`);
    }

    // Initial measure so the variables are correct before the first interaction.
    _measureAll();
    _attachObservers();

    // RESILIENT PUBLISH: boot can call this BEFORE the header has its final
    // laid-out height — on degraded / iOS boots especially — and a single measure
    // plus the observer can miss it, leaving --header-total-height /
    // --nav-dots-clearance EMPTY. The layout then uses the wrong hardcoded
    // fallback (110px) for the real header (~178px on iPad) and the routine title
    // creeps under the mode selector. Re-measure over the next frames until BOTH
    // variables are actually published.
    if (_retryRaf) cancelAnimationFrame(_retryRaf);
    let frames = 0;
    const isSet = (v) => getComputedStyle(document.documentElement).getPropertyValue(v).trim() !== '';
    const retry = () => {
        _retryRaf = null;
        _measureAll();
        _attachObservers();
        if ((isSet(HEADER_HEIGHT_VAR) && isSet(NAV_DOTS_CLEARANCE_VAR)) || frames++ > 30) return;
        _retryRaf = requestAnimationFrame(retry);
    };
    _retryRaf = requestAnimationFrame(retry);

    // Re-measure once fonts / async CSS have fully settled (belt-and-suspenders
    // for the empty-var case above).
    if (!_loadHandler) {
        _loadHandler = () => _measureAll();
        window.addEventListener('load', _loadHandler);
    }

    // Orientation / viewport changes alter `env(safe-area-inset-*)` and the
    // nav-dots' viewport position (it's anchored to the bottom) without the
    // observed elements always resizing — recompute both. Belt-and-suspenders.
    if (!_resizeHandler) {
        _resizeHandler = () => _measureAll();
        window.addEventListener('resize', _resizeHandler);
        window.addEventListener('orientationchange', _resizeHandler);
    }

    return !!_headerEl;
}

/**
 * Attach ResizeObservers to the live header / nav elements. Idempotent, and
 * split out so the retry loop can attach them once the elements actually exist
 * (the header may not be in the DOM at the first init call on a degraded boot).
 */
function _attachObservers() {
    if (typeof ResizeObserver === 'undefined') return;
    const headerEl = document.querySelector(DOM_SELECTORS.FIXED_HEADER_CONTAINER);
    const navEl = document.getElementById(DOM_IDS.NAV_DOTS);
    if (headerEl && !_headerObserver) {
        _headerObserver = new ResizeObserver(() => measureHeaderHeight());
        _headerObserver.observe(headerEl);
    }
    if (navEl && !_navObserver) {
        _navObserver = new ResizeObserver(() => measureNavDotsClearance());
        _navObserver.observe(navEl);
    }
}

/**
 * Disconnect the observers and remove listeners. Called on boot retry /
 * teardown and by tests.
 */
export function destroyHeaderLayout() {
    if (_headerObserver) {
        _headerObserver.disconnect();
        _headerObserver = null;
    }
    if (_navObserver) {
        _navObserver.disconnect();
        _navObserver = null;
    }
    if (_resizeHandler) {
        window.removeEventListener('resize', _resizeHandler);
        window.removeEventListener('orientationchange', _resizeHandler);
        _resizeHandler = null;
    }
    if (_loadHandler) {
        window.removeEventListener('load', _loadHandler);
        _loadHandler = null;
    }
    if (_retryRaf) {
        cancelAnimationFrame(_retryRaf);
        _retryRaf = null;
    }
    _headerEl = null;
    _navEl = null;
}
