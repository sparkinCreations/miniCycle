/**
 * Task Interactions Module (DI-Pure)
 *
 * Handles keyboard and accessibility interactions for tasks including:
 * - Keyboard navigation for task options
 * - Focus-based visibility toggling
 *
 * Pattern: Simple Instance ✨
 * - Single responsibility (keyboard/focus interactions)
 * - Required dependencies via diBase.js
 *
 * @module modules/ui/taskInteractions
 */

import { createDIModule, optional } from '../core/diBase.js';
import { DOM_CLASSES, DOM_SELECTORS } from '../core/constants.js';

// ============================================================================
// DEPENDENCY INJECTION SETUP (using diBase.js)
// ============================================================================
// NOTE: No dynamic imports - TaskOptionsVisibilityController comes through DI
// This avoids versioned/unversioned module instance mismatch issues

const di = createDIModule('TaskInteractions', {
    safeAddEventListener: optional(null),
    TaskOptionsVisibilityController: optional(null)
});

// Late-binding deps via Proxy
/** @type {{safeAddEventListener: Function|null, TaskOptionsVisibilityController: Object|null}} */
const _deps = new Proxy({}, {
    get(_, prop) {
        return di.resolve()[prop];
    }
});

/**
 * Set dependencies for TaskInteractions module
 * @param {Object} dependencies - Injected dependencies
 */
export function setTaskInteractionsDependencies(dependencies) {
    di.setDependencies(dependencies);
}

/**
 * Accessibility Helper: Toggles visibility of task buttons when task item is focused or blurred.
 *
 * When navigating with the keyboard (e.g., using Tab), this ensures that the task option buttons
 * (edit, delete, reminders, etc.) are shown while the task is focused and hidden when it loses focus.
 *
 * This provides a keyboard-accessible experience similar to mouse hover.
 *
 * @param {HTMLElement} taskItem - The task <li> element to attach listeners to.
 */
export function attachKeyboardTaskOptionToggle(taskItem) {
    const safeAddEventListener = _deps.safeAddEventListener;
    if (typeof safeAddEventListener !== 'function') {
        console.error('attachKeyboardTaskOptionToggle: safeAddEventListener dependency not set');
        return;
    }

    /**
     * Show task buttons when focus is inside a task.
     * Mouse/touch clicks on checkbox or task text are skipped (safe elements),
     * but keyboard focus (:focus-visible) on ANY element reveals options —
     * this gives keyboard-only users the same access as mouse hover.
     */
    safeAddEventListener(taskItem, "focusin", (e) => {
        const target = e.target;

        // Keyboard focus on any task element should reveal options (a11y parity with hover)
        const isKeyboardFocus = target.matches?.(':focus-visible');

        // Skip safe elements only for mouse/touch — keyboard always reveals
        if (!isKeyboardFocus) {
            if (
                target.classList.contains(DOM_CLASSES.TASK_TEXT) ||
                target.type === "checkbox" ||
                target.closest(DOM_SELECTORS.FOCUS_SAFE)
            ) {
                return;
            }
        }

        // Use centralized controller (handles mode checking automatically)
        if (_deps.TaskOptionsVisibilityController) {
            _deps.TaskOptionsVisibilityController.show(taskItem, 'focusin');
        }
    });

    /**
     * Hide task buttons when focus moves outside the entire task
     */
    safeAddEventListener(taskItem, "focusout", (e) => {
        if (taskItem.contains(e.relatedTarget)) return;

        // Use centralized controller (handles mode checking automatically)
        if (_deps.TaskOptionsVisibilityController) {
            _deps.TaskOptionsVisibilityController.hide(taskItem, 'focusout');
        }
    });
}

// DI-pure module (no window.* exports)
